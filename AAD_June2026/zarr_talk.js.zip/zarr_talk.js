const pptxgen = require("pptxgenjs");

let pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Zarr, Chunks & Virtualization";
pres.author = "Michael Sumner";

// Palette: deep ocean / data science feel
// Primary: deep navy 0A1628
// Secondary: ocean teal 0E7490
// Accent: seafoam 22D3EE / warm white F8FAFC
// Text dark: 1E293B, muted: 64748B

const C = {
  navy:    "0A1628",
  teal:    "0E7490",
  tealMid: "155E75",
  cyan:    "22D3EE",
  cyanPale:"CFFAFE",
  white:   "F8FAFC",
  offwhite:"E2E8F0",
  muted:   "94A3B8",
  dark:    "1E293B",
  green:   "10B981",
  amber:   "F59E0B",
  red:     "F43F5E",
};

// Helper: card background with shadow
function card(slide, x, y, w, h, fillColor, shadowOn=true) {
  slide.addShape(slide.pres ? slide.pres.shapes.ROUNDED_RECTANGLE : pres.shapes.ROUNDED_RECTANGLE, {
    x, y, w, h,
    fill: { color: fillColor },
    rectRadius: 0.12,
    shadow: shadowOn ? { type: "outer", color: "000000", blur: 8, offset: 3, angle: 45, opacity: 0.12 } : undefined
  });
}

// ─────────────────────────────────────────────
// SLIDE 1: Title
// ─────────────────────────────────────────────
{
  let sl = pres.addSlide();
  sl.background = { color: C.navy };

  // Large decorative grid of faint boxes top-right (evokes chunked array)
  const cols = 8, rows = 5;
  const bx = 5.8, by = 0.3, bw = 0.42, bh = 0.36, gap = 0.06;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const highlight = (r === 1 && c >= 2 && c <= 4) || (r === 2 && c >= 2 && c <= 4);
      sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
        x: bx + c * (bw + gap),
        y: by + r * (bh + gap),
        w: bw, h: bh,
        fill: { color: highlight ? C.teal : "132038", transparency: highlight ? 0 : 0 },
        line: { color: highlight ? C.cyan : "1E3A5F", width: highlight ? 1.5 : 0.8 },
        rectRadius: 0.04
      });
    }
  }

  sl.addText("Modern data accessibility\nand virtualization", {
    x: 0.5, y: 0.9, w: 6.8, h: 2.4,
    fontSize: 36, bold: true, color: C.white,
    fontFace: "Cambria",
    valign: "middle"
  });

  sl.addText("Cloud native: Zarr, chunks and virtualization\nin Python, GDAL, and R", {
    x: 0.5, y: 3.3, w: 6.5, h: 1.1,
    fontSize: 18, color: C.muted,
    fontFace: "Calibri",
    italic: true
  });

  sl.addText("Michael Sumner · Australian Antarctic Division", {
    x: 0.5, y: 4.9, w: 6, h: 0.5,
    fontSize: 12, color: C.muted, fontFace: "Calibri"
  });

  sl.addNotes(
    "5-minute overview: what Zarr is, why chunks matter, and the work bridging everything-was-Python to R and GDAL. " +
    "Start by saying: most of our data lives in HDF5/NetCDF files on disk or in the cloud. Zarr is the evolution of that idea."
  );
}

// ─────────────────────────────────────────────
// SLIDE 2: News montage — context setter
// ─────────────────────────────────────────────
{
  let sl = pres.addSlide();
  sl.background = { color: C.navy };

  const imgW = 1867, imgH = 1740, maxH = 4.6;
  const calcW = maxH * (imgW / imgH);
  const centreX = (10 - calcW) / 2;
  sl.addImage({
    path: "/mnt/user-data/uploads/1781057539665_image.png",
    x: centreX, y: 0.15, w: calcW, h: maxH
  });

  sl.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 4.9, w: 10, h: 0.725,
    fill: { color: C.navy }
  });

  sl.addText("June 2026 — the Zarr ecosystem is moving fast", {
    x: 0.5, y: 4.95, w: 7, h: 0.5,
    fontSize: 16, bold: true, color: C.cyan, fontFace: "Calibri", valign: "middle"
  });

  sl.addText("earthmover.io", {
    x: 7.5, y: 4.95, w: 2.2, h: 0.5,
    fontSize: 11, color: C.muted, fontFace: "Calibri", italic: true, align: "right", valign: "middle"
  });

  sl.addNotes(
    "Open with this slide — three headlines from the past two weeks. " +
    "NWS CIRRUS: Icechunk adopted as core format for US national weather service operational data. " +
    "Low Latency ERA5: global reanalysis on the Earthmover marketplace. " +
    "'Old format, no problem': GOES-16 archive virtualized as Virtual Zarr without copying data. " +
    "This is the momentum. Zarr and Icechunk are consolidating into production infrastructure — " +
    "and almost all of it assumes you're running Python. That's the gap this work addresses."
  );
}

// ─────────────────────────────────────────────
// SLIDE 2: What is Zarr?
// ─────────────────────────────────────────────
{
  let sl = pres.addSlide();
  sl.background = { color: "F8FAFC" };

  sl.addText("What is Zarr?", {
    x: 0.5, y: 0.25, w: 9, h: 0.7,
    fontSize: 32, bold: true, color: C.dark, fontFace: "Cambria"
  });

  // Left: concept text
  sl.addText([
    { text: "Chunked, compressed, N-dimensional arrays", options: { bold: true, breakLine: true, color: C.dark } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Each array is split into ", options: { color: C.dark } },
    { text: "rectangular chunks", options: { color: C.teal, bold: true } },
    { text: " — small tiles stored as independent files/objects", options: { color: C.dark, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Reads only fetch the chunks you touch → ", options: { color: C.dark } },
    { text: "no full-file download", options: { color: C.teal, bold: true, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Each chunk is ", options: { color: C.dark } },
    { text: "compressed, opaque bytes", options: { color: C.teal, bold: true } },
    { text: " — meaningless without the metadata", options: { color: C.dark, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Works ", options: { color: C.dark } },
    { text: "online", options: { color: C.teal, bold: true, breakLine: true } },
    { text: "s3:// gs:// http:// /vsicurl", options: { color: C.tealMid, fontFace: "Courier New", fontSize: 12, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Metadata stored separately (", options: { color: C.muted } },
    { text: ".zarray", options: { color: C.tealMid, fontFace: "Courier New" } },
    { text: ") — describes shape, chunk shape, compression details", options: { color: C.muted } },
  ], {
    x: 0.5, y: 1.1, w: 4.5, h: 3.8,
    fontSize: 15, fontFace: "Calibri", valign: "top"
  });

  // Right: drawn chunk grid diagram
  const gx = 5.4, gy = 1.0;
  const cw = 0.62, ch = 0.50, cgap = 0.05;
  const nc = 5, nr = 5;

  // Axis labels
  sl.addText("time →", { x: gx, y: gy - 0.32, w: nc * (cw + cgap), h: 0.25,
    fontSize: 10, color: C.muted, align: "center", fontFace: "Calibri", italic: true });
  sl.addText("↑ depth", { x: gx - 0.15, y: gy + nr * (ch + cgap) + 0.05, w: nc * (cw + cgap) + 0.3, h: 0.25,
    fontSize: 10, color: C.muted, align: "left", fontFace: "Calibri", italic: true });

  // (highlight label removed — visual is self-explanatory)

  for (let r = 0; r < nr; r++) {
    for (let c = 0; c < nc; c++) {
      const highlighted = (c >= 2 && c <= 3) && (r >= 1 && r <= 2);
      const fetched = highlighted;
      sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
        x: gx + c * (cw + cgap),
        y: gy + r * (ch + cgap),
        w: cw, h: ch,
        fill: { color: fetched ? C.teal : C.offwhite },
        line: { color: fetched ? C.cyan : "CBD5E1", width: fetched ? 2 : 1 },
        rectRadius: 0.05,
        shadow: fetched ? { type: "outer", color: "000000", blur: 6, offset: 2, angle: 45, opacity: 0.18 } : undefined
      });
      if (fetched) {
        sl.addText("✓", {
          x: gx + c * (cw + cgap),
          y: gy + r * (ch + cgap),
          w: cw, h: ch,
          fontSize: 14, color: C.cyanPale, align: "center", valign: "middle", fontFace: "Calibri"
        });
      }
    }
  }

  // (placeholder for borrowed chunk diagram)

  sl.addNotes(
    "Zarr is the modern format for multi-dimensional scientific arrays. " +
    "The key idea: instead of one monolithic file, data is split into chunks — independent tiles. " +
    "A query for one time-step of one depth range fetches only 2-3 chunks, not the whole archive. " +
    "This is why it works so well on cloud object stores."
  );
}

// ─────────────────────────────────────────────
// SLIDE 3: Virtualization — the key idea
// ─────────────────────────────────────────────
{
  let sl = pres.addSlide();
  sl.background = { color: "F8FAFC" };

  sl.addText("VZarr: virtualization at the chunk level", {
    x: 0.5, y: 0.25, w: 9, h: 0.7,
    fontSize: 32, bold: true, color: C.dark, fontFace: "Cambria"
  });

  // The central insight: a reference is (path, byte-offset, byte-length)
  // Show: HDF5 file → chunk reference table → virtual Zarr store

  // HDF5 box
  sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 0.35, y: 1.2, w: 2.3, h: 3.3,
    fill: { color: "FFF7ED" }, line: { color: C.amber, width: 2 }, rectRadius: 0.1
  });
  sl.addText("HDF5 / NetCDF", { x: 0.35, y: 1.2, w: 2.3, h: 0.45,
    fontSize: 12, bold: true, color: C.amber, align: "center", fontFace: "Calibri" });
  const rows5 = ["chunk 0,0", "chunk 0,1", "chunk 1,0", "chunk 1,1", "…"];
  rows5.forEach((label, i) => {
    sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: 0.5, y: 1.75 + i * 0.46, w: 2.0, h: 0.38,
      fill: { color: "FEF3C7" }, line: { color: C.amber, width: 1 }, rectRadius: 0.05
    });
    sl.addText(label, { x: 0.5, y: 1.75 + i * 0.46, w: 2.0, h: 0.38,
      fontSize: 11, color: "92400E", align: "center", valign: "middle", fontFace: "Courier New" });
  });

  // Arrow
  sl.addShape(pres.shapes.LINE, { x: 2.65, y: 2.85, w: 0.9, h: 0,
    line: { color: C.teal, width: 2.5 } });
  sl.addText("→", { x: 3.25, y: 2.65, w: 0.4, h: 0.4,
    fontSize: 18, color: C.teal, align: "center" });
  sl.addText("byte offset\n+ size", { x: 2.7, y: 3.05, w: 0.8, h: 0.55,
    fontSize: 9, color: C.tealMid, align: "center", fontFace: "Calibri", italic: true });

  // Reference table
  sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 3.55, y: 1.2, w: 3.2, h: 3.3,
    fill: { color: "F0FDFA" }, line: { color: C.teal, width: 2 }, rectRadius: 0.1
  });
  sl.addText("Kerchunk / Parquet refs", { x: 3.55, y: 1.2, w: 3.2, h: 0.45,
    fontSize: 12, bold: true, color: C.tealMid, align: "center", fontFace: "Calibri" });

  const headers = ["chunk", "path", "offset", "size"];
  const hx = [3.6, 4.05, 5.1, 5.85];
  const hw = [0.42, 1.02, 0.72, 0.7];
  headers.forEach((h, i) => {
    sl.addText(h, { x: hx[i], y: 1.7, w: hw[i], h: 0.3,
      fontSize: 9, bold: true, color: C.tealMid, align: "center", fontFace: "Calibri" });
  });

  const tdata = [
    ["0,0", "data.nc", "4096", "8192"],
    ["0,1", "data.nc", "12288", "8192"],
    ["1,0", "data.nc", "20480", "8192"],
    ["…",   "…",       "…",     "…"],
  ];
  tdata.forEach((row, ri) => {
    row.forEach((val, ci) => {
      sl.addText(val, { x: hx[ci], y: 2.08 + ri * 0.46, w: hw[ci], h: 0.38,
        fontSize: 10, color: C.dark, align: "center", valign: "middle",
        fontFace: ci === 1 ? "Courier New" : "Calibri" });
    });
  });

  // Arrow 2
  sl.addShape(pres.shapes.LINE, { x: 6.75, y: 2.85, w: 0.65, h: 0,
    line: { color: C.teal, width: 2.5 } });
  sl.addText("→", { x: 7.1, y: 2.65, w: 0.4, h: 0.4,
    fontSize: 18, color: C.teal, align: "center" });
  sl.addText("looks like\nZarr", { x: 6.7, y: 3.05, w: 0.8, h: 0.55,
    fontSize: 9, color: C.tealMid, align: "center", fontFace: "Calibri", italic: true });

  // Virtual Zarr box
  sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 7.45, y: 1.2, w: 2.2, h: 3.3,
    fill: { color: "F0FDF4" }, line: { color: C.green, width: 2 }, rectRadius: 0.1
  });
  sl.addText("Virtual Zarr store", { x: 7.45, y: 1.2, w: 2.2, h: 0.45,
    fontSize: 12, bold: true, color: C.green, align: "center", fontFace: "Calibri" });
  sl.addText("xarray / zarr-python\nsee native Zarr\n\nNo data moved.\nNo copy made.\n\nData stays in\noriginal files.", {
    x: 7.5, y: 1.75, w: 2.1, h: 2.6,
    fontSize: 11, color: "166534", fontFace: "Calibri", valign: "top", align: "center"
  });

  // Bottom key message
  sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 0.35, y: 4.7, w: 9.3, h: 0.62,
    fill: { color: C.navy }, rectRadius: 0.1
  });
  sl.addText("a reference is just (path, byte-offset, byte-length)", {
    x: 0.35, y: 4.7, w: 9.3, h: 0.62,
    fontSize: 14, bold: true, color: C.cyan, align: "center", valign: "middle", fontFace: "Calibri"
  });

  sl.addNotes(
    "Virtualization means building an index of where each chunk lives — its file path, byte offset, and size. " +
    "The original HDF5/NetCDF files stay untouched. We build a Parquet table of references. " +
    "Tools like xarray, zarr-python then read this as if it were a native Zarr store. " +
    "This is the kerchunk / VirtualiZarr approach. blocklist does this from R using GDAL + rhdf5."
  );
}

// ─────────────────────────────────────────────
// SLIDE 4: VRT — the intermediate form
// ─────────────────────────────────────────────
{
  let sl = pres.addSlide();
  sl.background = { color: "F8FAFC" };

  sl.addText("VRT: virtualization at the file level", {
    x: 0.5, y: 0.25, w: 9, h: 0.7,
    fontSize: 32, bold: true, color: C.dark, fontFace: "Cambria"
  });

  // Spectrum diagram: real files → VRT → kerchunk refs → full Zarr
  const specY = 1.25, specH = 0.7;
  const items = [
    { label: "Original\nHDF5 files", sub: "fully material", col: C.amber, x: 0.3, w: 1.9 },
    { label: "GDAL VRT", sub: "file-level virtual", col: C.teal, x: 2.5, w: 1.9 },
    { label: "kerchunk\nParquet refs", sub: "chunk-level virtual", col: C.tealMid, x: 4.7, w: 1.9 },
    { label: "Zarr store", sub: "fully virtual\n(or material)", col: C.green, x: 6.9, w: 1.9 },
  ];

  // Connecting arrow across
  sl.addShape(pres.shapes.LINE, { x: 0.35, y: specY + specH/2, w: 8.75, h: 0,
    line: { color: C.offwhite, width: 3 } });

  items.forEach(item => {
    sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: item.x, y: specY, w: item.w, h: specH,
      fill: { color: item.col }, rectRadius: 0.1,
      shadow: { type: "outer", color: "000000", blur: 6, offset: 2, angle: 45, opacity: 0.15 }
    });
    sl.addText(item.label, { x: item.x, y: specY, w: item.w, h: specH - 0.18,
      fontSize: 13, bold: true, color: "FFFFFF", align: "center", valign: "middle", fontFace: "Calibri" });
    sl.addText(item.sub, { x: item.x, y: specY + specH - 0.22, w: item.w, h: 0.22,
      fontSize: 8.5, color: "FFFFFF", align: "center", italic: true, fontFace: "Calibri" });
  });

  // Arrows between boxes
  [2.4, 4.6, 6.8].forEach(ax => {
    sl.addText("→", { x: ax, y: specY + specH/2 - 0.2, w: 0.3, h: 0.4,
      fontSize: 20, color: C.dark, align: "center", fontFace: "Calibri" });
  });

  // Left: VRT + R/GDAL story
  sl.addText("A GDAL VRT is an XML recipe — mosaic\n16 years of NetCDF into one logical array,\nwithout copying data.", {
    x: 0.5, y: 2.3, w: 4.5, h: 1.0,
    fontSize: 13, color: C.dark, fontFace: "Calibri", valign: "top"
  });

  sl.addText([
    { text: "It's ", options: { color: C.dark } },
    { text: "a pivot point", options: { bold: true, color: C.teal } },
    { text: " — GDAL already knows where every subfile chunk lives. virtualization turns that inside out:", options: { color: C.dark } },
  ], {
    x: 0.5, y: 3.38, w: 4.5, h: 0.72,
    fontSize: 13, fontFace: "Calibri", valign: "top"
  });

  // R+GDAL mini flow
  const rflow = [
    { label: "gdal mdim mosaic", sub: "→ VRT over all files" },
    { label: "rhdf5 chunk iter",  sub: "→ byte offset + size per chunk" },
    { label: "Parquet refs",      sub: "→ kerchunk-compatible store" },
  ];
  rflow.forEach((r, i) => {
    const ry = 4.15 + i * 0.42;
    sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: 0.5, y: ry, w: 4.4, h: 0.36,
      fill: { color: "F0FDFA" }, line: { color: C.teal, width: 1 }, rectRadius: 0.06
    });
    sl.addText(r.label, { x: 0.65, y: ry, w: 1.7, h: 0.36,
      fontSize: 11, bold: true, color: C.tealMid, fontFace: "Calibri", valign: "middle" });
    sl.addText(r.sub, { x: 2.35, y: ry, w: 2.4, h: 0.36,
      fontSize: 11, color: C.dark, fontFace: "Calibri", valign: "middle" });
  });

  // Right: looks a lot like Python
  sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 5.3, y: 2.25, w: 4.35, h: 3.1,
    fill: { color: "F8FAFC" }, line: { color: "CBD5E1", width: 1.5 }, rectRadius: 0.12
  });
  sl.addText("…looks a lot like", { x: 5.3, y: 2.25, w: 4.35, h: 0.42,
    fontSize: 13, bold: true, color: C.muted, align: "center", fontFace: "Calibri", italic: true });

  const pySteps = ["xarray → logical array", "VirtualiZarr / kerchunk → refs", "xarray + Icechunk → user access"];
  pySteps.forEach((s, i) => {
    sl.addText(s, { x: 5.45, y: 2.85 + i * 0.38, w: 4.0, h: 0.35,
      fontSize: 12, color: C.muted, fontFace: "Calibri", valign: "middle" });
  });

  sl.addText("Same outcome:\nkerchunk-Parquet refs readable\nby Python, R, and GDAL", {
    x: 5.45, y: 4.15, w: 3.9, h: 1.0,
    fontSize: 12, color: C.teal, bold: true, fontFace: "Calibri", valign: "top"
  });

  sl.addNotes(
    "The VRT is the key idea that makes blocklist possible. " +
    "gdal mdim mosaic builds a single virtual array over all HDF5 files (e.g., 16 years of BRAN2023 daily ocean data). " +
    "rhdf5 then iterates over the physical HDF5 chunks to get byte offsets. " +
    "These are joined to give chunk references that xarray/zarr-python can use as a native Zarr store. " +
    "Importantly, VRT allows intermediate forms — you're not forced to go all the way to full virtualization."
  );
}

// ─────────────────────────────────────────────
// SLIDE 5: The gap — Python → R/GDAL
// ─────────────────────────────────────────────
{
  let sl = pres.addSlide();
  sl.background = { color: C.navy };

  sl.addText("Multi-language support", {
    x: 0.5, y: 0.2, w: 9, h: 0.65,
    fontSize: 34, bold: true, color: C.white, fontFace: "Cambria"
  });

  // Two columns: Python world vs R/GDAL world
  // Left col: Python — mostly working but narrowing
  sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 0.35, y: 1.0, w: 4.2, h: 4.2,
    fill: { color: "132038" }, rectRadius: 0.12,
    shadow: { type: "outer", color: "000000", blur: 8, offset: 3, angle: 45, opacity: 0.2 }
  });
  sl.addText("Python-centric", { x: 0.35, y: 1.0, w: 4.2, h: 0.42,
    fontSize: 14, bold: true, color: C.amber, align: "center", fontFace: "Calibri" });
  sl.addText([
    { text: "kerchunk", options: { bold: true, color: C.cyan } },
    { text: " — the original reference builder", options: { color: C.offwhite, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 4 } },
    { text: "VirtualiZarr", options: { bold: true, color: C.cyan } },
    { text: " — modern, Xarray-native virtualization", options: { color: C.offwhite, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 4 } },
    { text: "Icechunk", options: { bold: true, color: C.red } },
    { text: " — transaction-robust, version-able Zarr\n  Rust-powered, xarray-centric", options: { color: C.offwhite, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 4 } },
    { text: "Assumption: you run Python, use xarray", options: { color: C.muted, italic: true } },
  ], {
    x: 0.5, y: 1.5, w: 3.9, h: 3.4,
    fontSize: 12.5, fontFace: "Calibri", valign: "top"
  });

  // Right col: R / GDAL solution
  sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 4.85, y: 1.0, w: 4.8, h: 4.2,
    fill: { color: "0C2A1A" }, rectRadius: 0.12,
    shadow: { type: "outer", color: "000000", blur: 8, offset: 3, angle: 45, opacity: 0.2 }
  });
  sl.addText("R + GDAL path", { x: 4.85, y: 1.0, w: 4.8, h: 0.42,
    fontSize: 14, bold: true, color: C.green, align: "center", fontFace: "Calibri" });
  sl.addText([
    { text: "gdal mdim get-refs", options: { bold: true, color: C.cyan } },
    { text: " — new GDAL CLI subcommand\n  extracting chunk refs to Parquet/GPKG", options: { color: C.offwhite, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 4 } },
    { text: "GDAL + Icechunk", options: { bold: true, color: C.cyan } },
    { text: " — on the radar:\n  /vsiicechunk/ VSI handler", options: { color: C.offwhite, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 4 } },
    { text: "pizzarr", options: { bold: true, color: C.cyan } },
    { text: " — R Zarr package", options: { color: C.offwhite, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 4 } },
    { text: "zaro", options: { bold: true, color: C.cyan } },
    { text: " — pure-R Zarr reader via Arrow FS", options: { color: C.offwhite, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 4 } },
    { text: "blocklist", options: { bold: true, color: C.cyan } },
    { text: " — kerchunk-Parquet from R\n  GDAL VRT + rhdf5 chunk iteration", options: { color: C.offwhite, breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 4 } },
    { text: "BRAN2023: 11 variables × 16 years\nvirtualized to Pawsey Acacia (AAD)", options: { color: C.green, italic: true, bold: true } },
  ], {
    x: 5.0, y: 1.5, w: 4.5, h: 3.4,
    fontSize: 12.5, fontFace: "Calibri", valign: "top"
  });

  sl.addNotes(
    "The Python ecosystem built kerchunk and VirtualiZarr, which are excellent. " +
    "But Icechunk — the next-generation transactional store — is heavily Python/Rust-native and narrows interoperability. " +
    "blocklist, zaro, and the new gdal mdim get-refs CLI subcommand bring this workflow to R and GDAL. " +
    "Concrete result: BRAN2023 ocean reanalysis — 11 variables, 16 years of daily data — " +
    "is now virtualized on Pawsey Acacia and accessible from R without downloading anything."
  );
}

// ─────────────────────────────────────────────
// SLIDE 7: What this enables (fused with data examples)
// ─────────────────────────────────────────────
{
  let sl = pres.addSlide();
  sl.background = { color: C.navy };

  sl.addText("What this enables", {
    x: 0.5, y: 0.2, w: 9, h: 0.65,
    fontSize: 34, bold: true, color: C.white, fontFace: "Cambria"
  });

  // ── LEFT COLUMN: No data movement + dataset list ──
  sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 0.35, y: 1.05, w: 4.4, h: 4.1,
    fill: { color: "0E4D6E" }, rectRadius: 0.12,
    shadow: { type: "outer", color: "000000", blur: 8, offset: 3, angle: 45, opacity: 0.2 }
  });
  sl.addText("📦  No data movement", {
    x: 0.53, y: 1.2, w: 4.0, h: 0.42,
    fontSize: 15, bold: true, color: C.cyan, fontFace: "Calibri"
  });
  sl.addText("Data stays in place. Access by reference.", {
    x: 0.53, y: 1.62, w: 4.0, h: 0.35,
    fontSize: 12, color: C.offwhite, fontFace: "Calibri", italic: true
  });

  const datasets = [
    { icon: "🌊", name: "BRAN2023", detail: "4D ocean model · 11 vars · ~6.5 TB/var · ~70 TB total", col: C.cyan },
    { icon: "🌡️", name: "GHRSST",   detail: "Sea surface temp · daily L4 · ~2 TB/variable", col: C.cyan },
    { icon: "🧊", name: "SEA ICE",  detail: "NSIDC (25km) + AMSR2 (3.125km) · daily 1978–now · ~20 GB", col: C.cyan },
    { icon: "✓",  name: "Altimetry", detail: "Already native Zarr · CMEMS", col: C.green },
  ];

  datasets.forEach((d, i) => {
    const dy = 2.1 + i * 0.73;
    sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: 0.53, y: dy, w: 3.9, h: 0.62,
      fill: { color: i === 3 ? "0C3320" : "0A2A40" }, rectRadius: 0.08,
      line: { color: i === 3 ? C.green : "1E5A7A", width: 1 }
    });
    sl.addText(d.icon + " " + d.name, {
      x: 0.65, y: dy, w: 1.35, h: 0.62,
      fontSize: 12, bold: true, color: d.col, fontFace: "Calibri", valign: "middle"
    });
    sl.addText(d.detail, {
      x: 2.05, y: dy, w: 2.25, h: 0.62,
      fontSize: 10, color: C.muted, fontFace: "Calibri", valign: "middle", italic: true
    });
  });

  // ── RIGHT COLUMN: 3 capability cards ──
  const rcards = [
    {
      icon: "⚡", title: "Partial reads",
      body: "Fetch only the time steps and depth levels you need — not the full 4D array.",
      col: "065A3A"
    },
    {
      icon: "🔗", title: "Interoperable",
      body: "Same Parquet refs read by Python (xarray/zarr), R (zaro), and GDAL.",
      col: "3D1A6E"
    },
    {
      icon: "🏗️", title: "Intermediate forms",
      body: "VRT lets you stop anywhere: file-virtual, chunk-virtual, or fully material.",
      col: "5C2A00"
    },
  ];

  rcards.forEach((c, i) => {
    const ry = 1.05 + i * 1.38;
    sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: 5.1, y: ry, w: 4.55, h: 1.25,
      fill: { color: c.col }, rectRadius: 0.12,
      shadow: { type: "outer", color: "000000", blur: 8, offset: 3, angle: 45, opacity: 0.2 }
    });
    sl.addText(c.icon + "  " + c.title, {
      x: 5.28, y: ry + 0.1, w: 4.1, h: 0.38,
      fontSize: 14, bold: true, color: C.cyan, fontFace: "Calibri"
    });
    sl.addText(c.body, {
      x: 5.28, y: ry + 0.48, w: 4.1, h: 0.68,
      fontSize: 11.5, color: C.offwhite, fontFace: "Calibri", valign: "top"
    });
  });

  sl.addText("github.com/mdsumner  ·  hypertidy.org  ·  blocklist / zaro / gdalraster", {
    x: 0.5, y: 5.22, w: 9, h: 0.28,
    fontSize: 10, color: C.muted, align: "center", fontFace: "Calibri", italic: true
  });

  sl.addNotes(
    "Left column: no data movement — data stays where it lives. The four stores we're actually working with: " +
    "BRAN2023 ocean reanalysis (done), GHRSST SST (in progress), NSIDC-0803 sea ice, and altimetry which is already native Zarr. " +
    "Right column: partial reads — fetch only what you need; interoperable — same reference files work in Python, R, and GDAL; " +
    "intermediate forms — VRT means you don't have to go all the way to full virtualization. Questions?"
  );
}

// ─────────────────────────────────────────────
// SLIDE 8: Closing / working group
// ─────────────────────────────────────────────
{
  let sl = pres.addSlide();
  sl.background = { color: C.navy };

  sl.addText("digital integration working group", {
    x: 0.5, y: 0.25, w: 9, h: 0.5,
    fontSize: 18, bold: false, color: C.muted, fontFace: "Calibri", italic: true
  });

  const items = [
    {
      label: "how we compute in science",
      sub: "laptops · servers · Nectar · HPC (Pawsey / NCI) · EC2 · Docker"
    },
    {
      label: "data delivery and monitoring",
      sub: "connection of data delivery to monitoring / EAMP"
    },
    {
      label: "Michael Sumner",
      sub: "Research Software Engineer\nTerrestrial and Nearshore Biodiversity and Conservation program"
    },
  ];

  items.forEach((item, i) => {
    const y = 1.05 + i * 1.45;
    sl.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: 0.5, y, w: 9.1, h: 1.25,
      fill: { color: "0D1E33" }, line: { color: "1E3A5F", width: 1 }, rectRadius: 0.1
    });
    sl.addText(item.label, {
      x: 0.75, y: y + 0.1, w: 8.6, h: 0.4,
      fontSize: 16, bold: true, color: C.cyan, fontFace: "Calibri"
    });
    sl.addText(item.sub, {
      x: 0.75, y: y + 0.5, w: 8.6, h: 0.65,
      fontSize: 13, color: C.offwhite, fontFace: "Calibri", valign: "top"
    });
  });

  sl.addText("github.com/mdsumner  ·  hypertidy.org", {
    x: 0.5, y: 5.2, w: 9, h: 0.28,
    fontSize: 10, color: C.muted, align: "center", fontFace: "Calibri", italic: true
  });

  sl.addNotes(
    "Closing slide — introduce yourself briefly, mention the working group is coming. " +
    "Key point: the diversity of computing environments at AAD means no single tool or pipeline fits everyone. " +
    "The connection between data delivery and monitoring (EAMP) is what motivates this work beyond just 'faster data access'."
  );
}

pres.writeFile({ fileName: "/mnt/user-data/outputs/zarr_virtualization_talk.pptx" })
  .then(() => console.log("Written."))
  .catch(e => { console.error(e); process.exit(1); });
